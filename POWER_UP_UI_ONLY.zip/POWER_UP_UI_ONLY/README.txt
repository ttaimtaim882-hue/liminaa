POWER UP - UI-only SwiftUI demo

Included:
- Blue/black POWER UP interface
- Demo access code: POWER
- LOGIN and LOG OUT screen states
- Telegram group link: https://t.me/UP_POWER1
- POWERUPLogo.png asset

To use in an ordinary SwiftUI iOS app:
1. Add PowerUpDemoView.swift to the app target.
2. Add POWERUPLogo.png to Assets.xcassets as an image set named POWERUPLogo.
3. Set PowerUpDemoView() as the app's displayed view.

This is an independent cosmetic interface only. It is not connected to game patching,
injection, exploit code, or remote API services. The access code is local demo logic,
not secure authentication.
