POWER UP — standalone SwiftUI UI demo

Includes:
- Blue/black POWER UP branding
- Demo login gate (code: POWER)
- Log out button
- Telegram group link: https://t.me/UP_POWER1
- Logo image asset

This is a standalone cosmetic demonstration and is not integrated with the uploaded project,
its patch/injection/exploit components, or remote APIs.

To use the logo in Xcode, add POWERUPLogo.png to an asset catalog named POWERUPLogo,
or import the image as a project resource and adjust Image("POWERUPLogo") accordingly.
